﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mobilecrud.Model
{
    public class MobileContext:DbContext
    {
        public MobileContext(DbContextOptions<MobileContext> options) : base(options)
        {

        }
        public DbSet<MobileRecord> mobileRe { get; set; }
        public DbSet<Brand> Brand { get; set; }

    }
}

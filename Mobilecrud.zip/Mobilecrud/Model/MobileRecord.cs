﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Mobilecrud.Model
{
    public class MobileRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public int MobileId { get; set; }
        [Required]
        public string MobileName { get; set; }

        [Required]
        public int pur_rate { get; set; }
        [Required]
        public int sale_sale { get; set; }
        [Required]
        public int mrp { get; set; }
        [Required]
        public int gst { get; set; }

        [ForeignKey("Brand")]
        public int BrandId { get; set; }
    }
}

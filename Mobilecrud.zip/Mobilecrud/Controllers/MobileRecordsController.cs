﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mobilecrud.Model;

namespace Mobilecrud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MobileRecordsController : ControllerBase
    {
        private readonly MobileContext _context;

        public MobileRecordsController(MobileContext context)
        {
            _context = context;
        }

        // GET: api/MobileRecords
        [HttpGet]
        public async Task<ActionResult<IEnumerable<MobileRecord>>> GetmobileRe()
        {
            return await _context.mobileRe.ToListAsync();
        }

        // GET: api/MobileRecords/5
        [HttpGet("{id}")]
        public async Task<ActionResult<MobileRecord>> GetMobileRecord(int id)
        {
            var mobileRecord = await _context.mobileRe.FindAsync(id);

            if (mobileRecord == null)
            {
                return NotFound();
            }

            return mobileRecord;
        }

        // PUT: api/MobileRecords/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutMobileRecord(int id, MobileRecord mobileRecord)
        {
            if (id != mobileRecord.MobileId)
            {
                return BadRequest();
            }

            _context.Entry(mobileRecord).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MobileRecordExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/MobileRecords
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<MobileRecord>> PostMobileRecord(MobileRecord mobileRecord)
        {
            _context.mobileRe.Add(mobileRecord);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetMobileRecord", new { id = mobileRecord.MobileId }, mobileRecord);
        }

        // DELETE: api/MobileRecords/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMobileRecord(int id)
        {
            var mobileRecord = await _context.mobileRe.FindAsync(id);
            if (mobileRecord == null)
            {
                return NotFound();
            }

            _context.mobileRe.Remove(mobileRecord);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool MobileRecordExists(int id)
        {
            return _context.mobileRe.Any(e => e.MobileId == id);
        }
    }
}
